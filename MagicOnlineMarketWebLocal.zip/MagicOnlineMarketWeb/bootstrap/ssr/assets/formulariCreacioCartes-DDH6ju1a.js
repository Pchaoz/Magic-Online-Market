import { ref, resolveComponent, withCtx, createVNode, unref, createTextVNode, withDirectives, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./GuestLayout-J8_xxBDr.js";
import { _ as _sfc_main$2, a as _sfc_main$3 } from "./TextInput-pYc-Ntiv.js";
import { useForm } from "@inertiajs/vue3";
import { P as PrimaryButton } from "./PrimaryButton-CZbnR4E4.js";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "formulariCreacioCartes",
  __ssrInlineRender: true,
  setup(__props) {
    const formCarta = useForm({
      nom: "",
      descripcio: "",
      imatge: "",
      raresa: "Comun"
    });
    const myfunction = () => {
      formCarta.post("/AddCarta");
    };
    const options = ref([
      {
        name: "Comun",
        value: "Comun"
      },
      {
        name: "Infrecuente",
        value: "Infrecuente"
      },
      {
        name: "Rara",
        value: "Rara"
      },
      {
        name: "Mitica",
        value: "Mitica"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = resolveComponent("Head");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Head, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<title${_scopeId2}>Afegir Carta</title>`);
                } else {
                  return [
                    createVNode("title", null, "Afegir Carta")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "nom",
              value: "Nom:"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "nom",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(formCarta).nom,
              "onUpdate:modelValue": ($event) => unref(formCarta).nom = $event,
              required: "",
              autofocus: "",
              autocomplete: "nom"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "descripcio",
              value: "Descripcio:"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "descripcio",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(formCarta).descripcio,
              "onUpdate:modelValue": ($event) => unref(formCarta).descripcio = $event,
              required: "",
              autofocus: "",
              autocomplete: "descripcio"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "imatge",
              value: "Imatge:"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "imatge",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(formCarta).imatge,
              "onUpdate:modelValue": ($event) => unref(formCarta).imatge = $event,
              required: "",
              autofocus: "",
              autocomplete: "imatge"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}><select id="raresa"${_scopeId}><!--[-->`);
            ssrRenderList(options.value, (option) => {
              _push2(`<option${ssrRenderAttr("value", option.value)}${_scopeId}>${ssrInterpolate(option.name)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="flex items-center justify-end mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              onClick: myfunction,
              class: ["ms-4", { "opacity-25": unref(formCarta).processing }],
              disabled: unref(formCarta).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Afegir `);
                } else {
                  return [
                    createTextVNode(" Afegir ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode(_component_Head, null, {
                default: withCtx(() => [
                  createVNode("title", null, "Afegir Carta")
                ]),
                _: 1
              }),
              createVNode("div", null, [
                createVNode(_sfc_main$2, {
                  for: "nom",
                  value: "Nom:"
                }),
                createVNode(_sfc_main$3, {
                  id: "nom",
                  type: "text",
                  class: "mt-1 block w-full",
                  modelValue: unref(formCarta).nom,
                  "onUpdate:modelValue": ($event) => unref(formCarta).nom = $event,
                  required: "",
                  autofocus: "",
                  autocomplete: "nom"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", null, [
                createVNode(_sfc_main$2, {
                  for: "descripcio",
                  value: "Descripcio:"
                }),
                createVNode(_sfc_main$3, {
                  id: "descripcio",
                  type: "text",
                  class: "mt-1 block w-full",
                  modelValue: unref(formCarta).descripcio,
                  "onUpdate:modelValue": ($event) => unref(formCarta).descripcio = $event,
                  required: "",
                  autofocus: "",
                  autocomplete: "descripcio"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", null, [
                createVNode(_sfc_main$2, {
                  for: "imatge",
                  value: "Imatge:"
                }),
                createVNode(_sfc_main$3, {
                  id: "imatge",
                  type: "text",
                  class: "mt-1 block w-full",
                  modelValue: unref(formCarta).imatge,
                  "onUpdate:modelValue": ($event) => unref(formCarta).imatge = $event,
                  required: "",
                  autofocus: "",
                  autocomplete: "imatge"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", null, [
                withDirectives(createVNode("select", {
                  id: "raresa",
                  "onUpdate:modelValue": ($event) => unref(formCarta).raresa = $event
                }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(options.value, (option) => {
                    return openBlock(), createBlock("option", {
                      key: option.name,
                      value: option.value
                    }, toDisplayString(option.name), 9, ["value"]);
                  }), 128))
                ], 8, ["onUpdate:modelValue"]), [
                  [vModelSelect, unref(formCarta).raresa]
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end mt-4" }, [
                createVNode(PrimaryButton, {
                  onClick: myfunction,
                  class: ["ms-4", { "opacity-25": unref(formCarta).processing }],
                  disabled: unref(formCarta).processing
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Afegir ")
                  ]),
                  _: 1
                }, 8, ["class", "disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/formulariCreacioCartes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
