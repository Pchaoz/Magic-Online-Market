import { withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./GuestLayout-J8_xxBDr.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./ApplicationLogo-3H3I4iid.js";
import "@inertiajs/vue3";
const _sfc_main = {
  __name: "llistaCartes",
  __ssrInlineRender: true,
  props: {
    cartes: {
      type: Array(String)
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<table class="table table-striped" data-v-d1211afa${_scopeId}><thead data-v-d1211afa${_scopeId}><tr data-v-d1211afa${_scopeId}><th data-v-d1211afa${_scopeId}>Nom Carta</th><th data-v-d1211afa${_scopeId}>Descripcio Carta</th><th data-v-d1211afa${_scopeId}>Imatge Carta</th><th data-v-d1211afa${_scopeId}>Raresa Carta</th></tr></thead><tbody data-v-d1211afa${_scopeId}><!--[-->`);
            ssrRenderList(__props.cartes, (carta) => {
              _push2(`<tr data-v-d1211afa${_scopeId}><td data-v-d1211afa${_scopeId}>${ssrInterpolate(carta.nom)}</td><td data-v-d1211afa${_scopeId}>${ssrInterpolate(carta.descripcio)}</td><td data-v-d1211afa${_scopeId}>${ssrInterpolate(carta.imatge)}</td><td data-v-d1211afa${_scopeId}>${ssrInterpolate(carta.raresa)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table>`);
          } else {
            return [
              createVNode("table", { class: "table table-striped" }, [
                createVNode("thead", null, [
                  createVNode("tr", null, [
                    createVNode("th", null, "Nom Carta"),
                    createVNode("th", null, "Descripcio Carta"),
                    createVNode("th", null, "Imatge Carta"),
                    createVNode("th", null, "Raresa Carta")
                  ])
                ]),
                createVNode("tbody", null, [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.cartes, (carta) => {
                    return openBlock(), createBlock("tr", {
                      key: carta.id
                    }, [
                      createVNode("td", null, toDisplayString(carta.nom), 1),
                      createVNode("td", null, toDisplayString(carta.descripcio), 1),
                      createVNode("td", null, toDisplayString(carta.imatge), 1),
                      createVNode("td", null, toDisplayString(carta.raresa), 1)
                    ]);
                  }), 128))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/llistaCartes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const llistaCartes = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d1211afa"]]);
export {
  llistaCartes as default
};
