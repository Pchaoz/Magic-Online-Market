<template>

        <img src='images/MMO_logo.png' alt="Laravel Logo" style="width: 80px; height: 80px;">

</template>
